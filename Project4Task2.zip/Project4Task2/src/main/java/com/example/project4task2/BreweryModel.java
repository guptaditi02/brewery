// Authored by: Aditi Gupta
// Andrew ID: argupta
// Project 4 Task 2
// Taken help from Project1Task2 For MVC Structure
// Taken help from Project4Task1 for MongoDB
// Taken assistance from ChatGPT for completing the code and adding the comments

package com.example.project4task2;

import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Sorts;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;

public class BreweryModel {
    private MongoCollection<Document> logCollection; // MongoDB collection for logging

    public BreweryModel(MongoCollection<Document> logCollection) {
        this.logCollection = logCollection;
    }

    // Method to handle the dashboard request
    public void handleDashboardRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        // Collect operations analytics data
        List<Document> topCitySearches = getTopCitySearches(5); // Replace with your implementation
        String topDayOfWeek = getTopDayOfWeek(); // Replace with your implementation
        List<Document> topAndroidPhoneModels = getTopAndroidPhoneModels(5); // Replace with your implementation

        // Collect log data
        List<Document> logs = logCollection.find().into(new ArrayList<>());
        // Set data as request attributes for rendering in the JSP
        request.setAttribute("topCitySearches", topCitySearches);
        request.setAttribute("topDayOfWeek", topDayOfWeek);
        request.setAttribute("topAndroidPhoneModels", topAndroidPhoneModels);
        request.setAttribute("logs", logs);

        // Forward the request to the JSP for rendering
        RequestDispatcher dispatcher = request.getRequestDispatcher("/dashboard.jsp");
        dispatcher.forward(request, response);
    }

    // Method to add log information to the database
    public void addLogToDatabase(String city, Date requestTimestamp, Date responseTimestamp, String dayOfWeek, String mobileModel, String jsonResponse) {
        // Create a document to store log information
        Document document = new Document("city", city)
                .append("requestTimestamp", requestTimestamp)
                .append("responseTimestamp", responseTimestamp)
                .append("dayOfWeek", dayOfWeek)
                .append("mobileModel", mobileModel)
                .append("jsonResponse", jsonResponse);

        // Add the document to the "logs" collection
        logCollection.insertOne(document);
    }

    // Method to fetch breweries from a third-party API
    public String fetchBreweries(String city) {
        try {
            // Connects to the third-party API
            URL url = new URL("https://api.openbrewerydb.org/breweries?by_city=" + city);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            // Reads the response
            Scanner scanner = new Scanner(url.openStream());
            String response = scanner.useDelimiter("\\A").next();
            scanner.close();
            return response;

        } catch (Exception e) {
            e.printStackTrace();
            return "{}"; // Returns empty JSON in case of error
        }
    }

    // Method to get the day of the week from a given date
    public String getDayOfWeek(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE", Locale.ENGLISH);
        return sdf.format(date);
    }

    // Method to get the top city searches
    public List<Document> getTopCitySearches(int limit) {
        List<Document> topCitySearches = new ArrayList<>();

        AggregateIterable<Document> aggregation = logCollection.aggregate(Arrays.asList(
                Aggregates.group("$city", Accumulators.sum("count", 1)),
                Aggregates.sort(Sorts.descending("count")),
                Aggregates.limit(limit)
        ));

        for (Document doc : aggregation) {
            topCitySearches.add(new Document("city", doc.get("_id")).append("count", doc.get("count")));
        }
        return topCitySearches;
    }

    // Method to get the top day of the week
    public String getTopDayOfWeek() {
        AggregateIterable<Document> aggregation = logCollection.aggregate(Arrays.asList(
                Aggregates.group("$dayOfWeek", Accumulators.sum("count", 1)),
                Aggregates.sort(Sorts.descending("count")),
                Aggregates.limit(1)
        ));

        Document topDayDoc = aggregation.first();
        if (topDayDoc != null) {
            return topDayDoc.getString("_id");
        }
        return "N/A";
    }

    // Method to get the top Android phone models
    public List<Document> getTopAndroidPhoneModels(int limit) {
        List<Document> topAndroidModels = new ArrayList<>();

        AggregateIterable<Document> aggregation = logCollection.aggregate(Arrays.asList(
                Aggregates.group("$mobileModel", Accumulators.sum("count", 1)),
                Aggregates.sort(Sorts.descending("count")),
                Aggregates.limit(limit)
        ));

        for (Document doc : aggregation) {
            topAndroidModels.add(new Document("model", doc.get("_id")).append("count", doc.get("count")));
            System.out.println(doc.get("_id"));
        }
        return topAndroidModels;
    }

    // Method to format the JSON response
    public String formatJsonResponse(String jsonResponse) {
        try {
            JSONArray jsonArray = new JSONArray(jsonResponse);
            StringBuilder formattedData = new StringBuilder();

            for (int i = 0; i < 1; i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                // Extract other fields in a similar way
                formattedData.append("Brewery Name: ").append(jsonObject.getString("name")).append("\n");
                formattedData.append("Type: ").append(jsonObject.getString("brewery_type")).append("\n");
                // Check if the "address_1" field is a string before extracting it
                if (jsonObject.has("address_1") && !jsonObject.isNull("address_1")) {
                    formattedData.append("Address: ").append(jsonObject.getString("address_1")).append("\n");
                }
                formattedData.append("City: ").append(jsonObject.getString("city")).append("\n");
                formattedData.append("State: ").append(jsonObject.getString("state")).append("\n");
                formattedData.append("Postal Code: ").append(jsonObject.getString("postal_code")).append("\n");
                formattedData.append("Country: ").append(jsonObject.getString("country")).append("\n");
                formattedData.append("Phone: ").append(jsonObject.optString("phone")).append("\n");
                formattedData.append("Website: ").append(jsonObject.optString("website_url")).append("\n\n");
            }

            // Return the formatted data as a plain text string
            return formattedData.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            return "Error formatting JSON response: " + e.getMessage();
        }
    }
}
