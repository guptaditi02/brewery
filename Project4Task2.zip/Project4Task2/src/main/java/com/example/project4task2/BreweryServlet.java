// Authored by: Aditi Gupta
// Andrew ID: argupta
// Project 4 Task 2
// Taken help from Project1Task2 For MVC Structure and for having two URLs in the same servlet
// Taken help from Project4Task1 for MongoDB
// Taken assistance from ChatGPT for completing the code and adding the comments

package com.example.project4task2;

import com.mongodb.client.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

@WebServlet(name = "BreweryServlet", urlPatterns = {"/brewery", "/dashboard"})
public class BreweryServlet extends HttpServlet {
    private MongoClient mongoClient;
    private MongoCollection<Document> logCollection;
    private BreweryModel breweryModel;

    @Override
    public void init() {
        // Initialize MongoDB connection and collection here
        String connectionString = "mongodb://argupta:guptaditi02@ac-jv29eou-shard-00-00.v2rvf9h.mongodb.net:27017,ac-jv29eou-shard-00-01.v2rvf9h.mongodb.net:27017,ac-jv29eou-shard-00-02.v2rvf9h.mongodb.net:27017/myFirstDatabase?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
        mongoClient = MongoClients.create(connectionString);
        MongoDatabase database = mongoClient.getDatabase("breweryDatabase");
        logCollection = database.getCollection("logs");
        breweryModel = new BreweryModel(logCollection);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        // Check if the request is for the dashboard
        if ("/dashboard".equals(request.getServletPath())) {
            // Call the handleDashboardRequest method in the BreweryModel to handle the dashboard request
            breweryModel.handleDashboardRequest(request, response);
            return; // Return to exit the doGet method after handling the dashboard request
        }
        // Receives the city parameter from the Android app
        String city = request.getParameter("city");

        // Track request timestamp
        Date requestTimestamp = new Date();

        // Fetches information from the third-party API using methods from the BreweryModel
        String jsonResponse = breweryModel.fetchBreweries(city);
        // Format the JSON response using methods from the BreweryModel
        String formattedJsonResponse = breweryModel.formatJsonResponse(breweryModel.fetchBreweries(city));

        // Track response timestamp
        Date responseTimestamp = new Date();

        // Get the day of the week for the request using methods from the BreweryModel
        String dayOfWeek = breweryModel.getDayOfWeek(requestTimestamp);

        // Get mobile from which the request was received (you can retrieve this information from request headers)
        String mobileModel = request.getHeader("User-Agent");

        // Add logging information to the database using methods from the BreweryModel
        breweryModel.addLogToDatabase(city, requestTimestamp, responseTimestamp, dayOfWeek, mobileModel, formattedJsonResponse);

        // Sets the response type and encoding
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // Sends the response back to the Android app
        PrintWriter out = response.getWriter();
        out.print(jsonResponse);
        out.flush();
    }


    @Override
    public void destroy() {
        // Close the MongoDB connection when the servlet is destroyed
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
}
